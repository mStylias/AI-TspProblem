namespace Tsp.Logging;

public enum DisplayFormat
{
    Decimal,
    Binary
}